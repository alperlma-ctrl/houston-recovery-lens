import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import pandas as pd,numpy as np
from train_wind_model import make_samples,FEATURES

w=pd.read_csv(ROOT/'data/houston_major_storms_hourly_weather.csv')
g=w[(w.storm_event=='Hurricane_Beryl_2024')&(w.location=='Harris (Houston)')].sort_values('time').reset_index(drop=True)
t=20;before=make_samples(g)
changed=g.copy();changed.loc[t+1:, 'wind_gusts_10m']=199
changed.loc[t+1:, 'surface_pressure']=900
changed.loc[t+1:, 'precipitation']=99
after=make_samples(changed)
a=before[before.time==g.iloc[t].time].iloc[0];b=after[after.time==g.iloc[t].time].iloc[0]
assert np.array_equal(a[FEATURES].to_numpy(),b[FEATURES].to_numpy()), 'Future perturbation changed an input feature'
assert a.target!=b.target and b.target==199
assert a.target_start>a.time
print('PASS: changing every future gust, pressure, and rain value leaves current features unchanged; target changes correctly.')
