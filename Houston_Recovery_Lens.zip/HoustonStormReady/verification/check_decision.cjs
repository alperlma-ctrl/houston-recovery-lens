const fs=require('fs'),vm=require('vm'),assert=require('assert');
const path=require('path'),root=path.resolve(__dirname,'..');
const context=vm.createContext({window:{DECISION_DATA:JSON.parse(fs.readFileSync(path.join(root,'results/decision_data.json'),'utf8'))},console});
vm.runInContext(fs.readFileSync(path.join(root,'demo/decision.js'),'utf8'),context);
const checks=vm.runInContext(`(()=>{let cases=0;for(let mask=1;mask<16;mask++){roomState.mask=mask;for(const budget of [5,7,17,99,100,137,1000]){roomState.budget=budget;for(const name of ['Equal','Historical mix','Stress-tested']){const a=roomPolicy(name);if(a.reduce((a,b)=>a+b,0)!==budget||a.some(v=>!Number.isInteger(v)||v<0))throw Error('Invalid allocation');const score=roomWorst(a);if(score<0||score>1+1e-10)throw Error('Invalid score');cases++;}if(roomWorst([0,0,0,0,0])!==0)throw Error('Unassigned slots must lose overlap');} }return cases;})()`,context);
assert.equal(checks,315);
console.log('PASS: 315 policy/budget/scenario combinations; integer budgets, bounded overlap, and unassigned-slot behavior.');
