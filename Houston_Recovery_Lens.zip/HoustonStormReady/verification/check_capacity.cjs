const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'../demo/wind.js'),'utf8');
const context={window:{WIND_DATA:{}}};vm.createContext(context);vm.runInContext(source,context);
const allocate=context.allocateCapacity;
const cases=[
 [{A:0,B:0,C:0},100,5], [{A:10,B:20,C:30},0,5],
 [{A:10,B:20,C:30},100,5], [{A:10,B:20,C:30},3,5],
 [{A:10,B:20,C:30},25,2], [{A:1,B:0,C:1},1,8],
 [{A:99999,B:20,C:30},1000,10],
];
for(let i=0;i<100;i++)cases.push([{A:i*3,B:100-i,C:i%9},i*2,i%11]);
for(const [demands,capacity,floor] of cases){
 const r=allocate(demands,capacity,floor),sum=Object.values(r.allocation).reduce((s,n)=>s+n,0),total=Object.values(demands).reduce((s,n)=>s+n,0);
 assert.equal(sum,Math.min(capacity,total));assert.equal(r.used,sum);assert.equal(r.unmet,total-sum);
 for(const c of Object.keys(demands)){assert(Number.isInteger(r.allocation[c]));assert(r.allocation[c]>=0);assert(r.allocation[c]<=demands[c]);}
 assert.deepEqual(allocate(demands,capacity,floor),r);
}
console.log('PASS: '+cases.length+' allocation cases conserve slots, respect demand caps, return integers, and remain deterministic.');
