# Houston Recovery Lens

A Track 1 hurricane preparedness and recovery project for the Code[Coogs] AI Hackathon on October 23, 2026.

Recovery Lens compares historical assessed building damage in flood insurance claim records across four storms and five Greater Houston counties. It combines the organizer's claims, hourly weather, and county boundaries into an interactive explorer. The project also trains and evaluates predictive models, records their failure on Beryl, and prevents those failed predictions from being used in the demo.

## Open the demo

Open `demo/index.html` in your browser. The demo works from the extracted folder without installing Python, starting a server, entering an API key, or signing into another service. An internet connection loads the preferred fonts; system fonts work offline.

The hosted site was registered privately, but publication was blocked by this session’s source-synchronization approval policy. Use the working offline demo. No hosted URL is claimed as published.

## Present it

1. Open **Explore storms**, with **Beryl** and **Harris** selected.
2. Choose **Harvey**, then return to **Beryl**, to compare recorded recovery burdens.
3. Select **Zone X** to show a more specific historical cohort.
4. Export a county comparison if useful.
5. Open **Model evidence** and explain why the candidate forecast was rejected.
6. Use **Presentation guide** or `PRESENTATION_GUIDE.md` for the two-minute script and common questions.

The supplied hacker packet calls for a live demo and short pitch, ready by **4:30 p.m. Central on October 23, 2026**. It does not require a file upload. Any later organizer instructions take precedence for the actual event format.

## What is included

- `demo/`: complete browser demo, including aggregate data and county boundaries.
- `analysis.ipynb`: analysis notebook with executed outputs and plain-language explanations.
- `train_model.py`: reproducible cleaning, joining, model fitting, validation, and test pipeline.
- `data/`: the four original organizer files.
- `results/`: metrics, quality audit, file hashes, county summaries, fitted model, and rejected model outputs.
- `PRESENTATION_GUIDE.md`: pitch, live demo steps, and answers to likely judge questions.
- `requirements.txt`: the Python package versions used for the analysis.

## Reproduce the analysis

Use Python 3.12. From this folder, install `requirements.txt`, then run `python train_model.py`. Open `analysis.ipynb` in Jupyter or Colab to inspect the analysis. In Colab, the first cell accepts the complete project ZIP when the files are not already present.

Only load `trained_model.joblib` from this project or another trusted source. Its predictions are retained for reproducibility and are not suitable for planning.

## Data scope

The source has **80,547 claim records**. We select single-family occupancy codes 1 and 11, restrict to the four storms with matching weather, keep known nonnegative assessed building damage, and require building insurance coverage between $1 and $250,000. The result contains **60,020 eligible records**.

The five supported counties are Brazoria, Fort Bend, Galveston, Harris, and Montgomery. Austin, Chambers, Liberty, and Waller have supplied boundary polygons but no matched claims and weather in this project. The weather contains **3,960 hourly rows**, aggregated into **20 county/storm groups**. Many claim rows do not create additional independent storm observations.

Claims and weather are joined by normalized storm identity and county. County FIPS are kept as five-character strings. Every merge checks that a claim joins to exactly one weather summary. Missing damage is excluded and never converted to zero. No unique claim or property ID was provided, so repeat properties across storms cannot be ruled out.

## Model experiment

The target is `buildingDamageAmount`, assessed structural damage in nominal dollars. It is separate from payout, contents damage, and the probability of making a claim. Features are county, grouped recorded flood zone, building insurance coverage, full-window rainfall, and maximum wind gust. Excluded inputs include all payout and damage fields, water depth, storm name, and loss date.

- **Train:** Harvey 2017 and Imelda 2019, 58,229 eligible claims. Each storm gets equal total fitting weight.
- **Select:** Nicholas 2021, 169 claims. Compare the training median baseline, a shallow decision tree, and ridge regression using mean absolute error.
- **Test:** Beryl 2024, 1,622 claims. Select the model before inspecting this test result.

Ridge regression had the lowest Nicholas error, about **$10,560 per claim**. On Beryl its error was **$19,724**, compared with **$51,050** for the training-median baseline. However, **every Beryl prediction was clipped to zero**. Always predicting zero has the same Beryl error. The test R² is **−0.626**.

**The candidate model is rejected for planning use.** The apparent improvement against one weak baseline does not establish useful prediction. No model outputs drive the historical explorer. A future iteration should include a zero diagnostic and stronger baselines from the start, add independent storms and exposure/property data, and retain a fresh storm for final evaluation.

## Interpretation

Historical totals sum the eligible supplied claim records. They do not estimate total community losses, uninsured damage, number of distinct homes, future flood probability, emergency resource need, or insurance payout. No population or insurance-exposure denominator was supplied. Amounts are nominal dollars without inflation adjustment. Weather is historical reanalysis at one reference point per county; supplied storm windows vary in duration. There are no operational weather forecasts or outage labels.

Zone X is a recorded flood-zone designation. Its share of claims is not a flood risk rate. Small historical damage summaries with fewer than 20 eligible claims are suppressed in the demo. County comparison exports cover all zones for the selected county, independent of the zone filter in the detail card.

## Sources and attribution

The organizer's shared folder and brief were accessed on October 23, 2026:

- [Organizer dataset folder](https://drive.google.com/drive/folders/1doFLc1xXvUDTBvoDg0wmebjGIaaCCy0a)
- [Challenge 1 dataset brief](https://docs.google.com/document/d/1n9FrZHastJOO1jy2f6X_PbYukTuAnrWgbJugyTK3lkw/edit)

The brief attributes claims to OpenFEMA NFIP, weather to Open-Meteo historical ERA5, tracks to NOAA IBTrACS, and boundaries to the U.S. Census Bureau. Original files are retained without modification and their hashes are in `results/data_manifest.json`. This project uses the provided extracts; their upstream extraction procedures were not independently reproduced. Hurricane tracks are inspected for context and are not used as extra damage labels.

AI assistance was used to build the project. Explain this openly if asked. The presenter should review the demo and understand the distinction between historical evidence and a successful predictive model.
