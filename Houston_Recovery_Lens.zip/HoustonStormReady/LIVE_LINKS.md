# Hurricane Recovery Model (HRM)

Both websites are published in the UH HACKATHON Vercel Hobby workspace and were verified without signing in.

- Application: https://hurricane-recovery-model-hrm.vercel.app/
- Presenter’s playbook: https://hrm-presenter-playbook.vercel.app/

The playbook’s “Open the demo” button opens the live application. The saved standalone HTML files remain available for offline presentations.
