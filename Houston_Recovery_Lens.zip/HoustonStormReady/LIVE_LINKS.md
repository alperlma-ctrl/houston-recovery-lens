# Live application

https://hurricane-recovery-model-hrm.vercel.app/

The application is also available offline in OPEN_DEMO.html.
